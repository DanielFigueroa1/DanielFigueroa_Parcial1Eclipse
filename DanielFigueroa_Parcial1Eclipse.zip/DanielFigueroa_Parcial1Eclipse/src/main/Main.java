package main;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

import com.google.gson.Gson;

import processing.core.PApplet;

public class Main extends PApplet implements Observer{
	private BufferedWriter writer;
	private TCPSingleton tcp;
	private Socket socket;
	private int xC;
	private int yC;
	private String usuarioNombre;
	private int rojoC;
	private int verdeC;
	private int azulC;
	Usuario usuario;

	
	public static void main(String[] args) {
		PApplet.main(Main.class.getName());
		
	}
	
	
	public void settings() {
		size (800,600);
	}
	
	public void setup() {
		xC = 200;
		yC = 200;
		usuarioNombre = "nombre";
		rojoC = 255;
		verdeC = 0;
		azulC = 0;
		
		tcp = TCPSingleton.getInstance();
		tcp.setObserver(this);
		tcp.start();
		
		
	}
	
	public void draw() {
		background(0);
		text (usuarioNombre, xC-20,yC-50);
		fill (rojoC,verdeC,azulC);
		ellipse(xC, yC, 60,60);
	}


public void RecibirMensaje(String line) {
		
		Gson gson = new Gson();
		Usuario datosUsuario = gson.fromJson(line, Usuario.class);
		String registro=datosUsuario.getNombre();
		datosUsuario.getVel();
		
		
		rojoC = datosUsuario.getRojo();
		verdeC = datosUsuario.getVerde();
		azulC = datosUsuario.getAzul();
		usuarioNombre = registro;
		xC = datosUsuario.getPosX();
		yC = datosUsuario.getPosY();
		
	}
}
	
	
	
