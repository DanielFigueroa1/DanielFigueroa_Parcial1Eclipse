package main;

public interface Observer { //observar el singleton
	void RecibirMensaje(String line);
}
